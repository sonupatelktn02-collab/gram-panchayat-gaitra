create table if not exists public.complaints (
 id uuid primary key default gen_random_uuid(),
 complaint_code text unique not null,
 name text not null, mobile text, category text not null, place text,
 description text not null, video_path text, photo_path text,
 status text not null default 'Pending' check(status in ('Pending','In Progress','Resolved','Rejected')),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.admin_users(user_id uuid primary key references auth.users(id) on delete cascade);
alter table public.complaints enable row level security;
alter table public.admin_users enable row level security;
create policy "public insert complaints" on public.complaints for insert to anon,authenticated with check(true);
create policy "public lookup complaints" on public.complaints for select to anon,authenticated using(true);
create policy "admin update complaints" on public.complaints for update to authenticated using(exists(select 1 from public.admin_users a where a.user_id=auth.uid())) with check(exists(select 1 from public.admin_users a where a.user_id=auth.uid()));
insert into storage.buckets(id,name,public) values('complaint-media','complaint-media',true) on conflict(id) do update set public=true;
create policy "public upload media" on storage.objects for insert to anon,authenticated with check(bucket_id='complaint-media');
create policy "public view media" on storage.objects for select to anon,authenticated using(bucket_id='complaint-media');
-- Admin user बनाने के बाद उसका UUID लेकर यह चलाएं:
-- insert into public.admin_users(user_id) values ('YOUR-ADMIN-UUID');
