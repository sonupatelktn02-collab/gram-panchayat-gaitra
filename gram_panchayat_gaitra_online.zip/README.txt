ग्राम पंचायत गैतरा - Online Supabase Version

1. Supabase Dashboard > SQL Editor > setup.sql की पूरी सामग्री Run करें।
2. Authentication > Users में Admin email/password बनाएं।
3. उस user का UUID लेकर SQL Editor में:
   insert into public.admin_users(user_id) values ('ADMIN-UUID');
4. index.html और config.js को hosting पर publish करें।

यह version public complaint + video/photo upload + Complaint ID tracking + Admin status update के लिए तैयार है।
